#!/bin/bash
if [ "$1" == "-help" ]; then
    echo "Uso: $0 [origen][destino]"
    exit 0
fi
if [ ! -d "$1" ] || [ ! -d "$2" ];  then
    echo "Error: Directorios invalidos"
    exit 1
fi
FECHA=$(date +"%Y%m%d")
NAME=$(basename "$1")
tar -czf "$2/$NAME_bkp_$FECHA.tar.gz" -C "$(dirname "$1")" "$NAME"
echo "Backup completado"
