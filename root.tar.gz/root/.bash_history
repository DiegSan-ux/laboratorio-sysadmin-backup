history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
ip a
hostnamectl set-hostname TPServer
nano /etc/hosts
nano /etc/hosts
apt update
apt update && apt install nano -y
apt install nano 
dpkg-reconfigure keyboard-configuration
localectl set-keymap us
reboot
nano /etc/hosts
echo "nameserver 8.8.8.8" > /etc/resolv.conf
apt update && apt install nano -y
echo "nameserver 8.8.8.8" > /etc/resolv.conf
sed -i 's/bullseye/bookworm/g' /etc/apt/sources.list
apt update && apt install nano -y
apt update
ping -c 3 8.8.8.8
echo "nameserver 8.8.8.8" | tee /etc/resolv.conf
ping -c 3 google.com
apt update && apt install nano -y
sed -i 's/cdn2-fastly.debian.org/deb.debian.org/g' /etc/apt/sources.list
rm -rf /var/lib/apt/lists/* && apt update
apt install nano -y
ip -br a
nano /etc/network/interfaces
systemctl restart networking
ip -br a
shutdown -h now
lsblk
echo '---' > /sys/class/scsi_host/host0/scan
echo "---" > /sys/class/scsi_host/host0/scan
poweroff
lsblk
fdisk /dev/sdc
lsblk
mkfs.ext4 /dev/sdc1
fdisk /dev/sdc
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir /www_dir
mkdir /backup_dir
nano /etc/fstab
mount -a
df -h
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.png /www_dir/
nano /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
nano /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
cat /proc/partitions > /opt/particion
poweroff
